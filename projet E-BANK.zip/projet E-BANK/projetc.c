#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <windows.h>
#include <time.h>
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_RESET   "\x1b[0m"

typedef struct {
    int clientID;
    char nom[100];
    char prenom[100];
    char adr[200];
} Client;
typedef struct CompteBancaire {
    int numcompte;
    Client clt;
    float solde;
    struct CompteBancaire *suivant;
} CompteBancaire;

typedef struct{
    int numcompte;
    float montant,soldeavant,soldeapres;
    char description[100];
    char date[15];
} Transaction;
typedef struct Noeud{
    Transaction transactions;
    struct Noeud* suiv;
} Noeud;
typedef struct {
    Noeud* sommet; // Pointeur vers le sommet de la pile
} TransactionStack;
void empiler (TransactionStack *stack,Transaction trans)
{ Noeud * nouveau;
nouveau = (Noeud*) malloc (sizeof(Noeud));
(*nouveau).transactions = trans;
if (stack->sommet == NULL) {
        stack->sommet = nouveau;
        nouveau->suiv = NULL;
    } else {
        nouveau->suiv = stack->sommet;
        stack->sommet = nouveau;
    }
}
void color_text(char text[100], int color_code){
    char c[100];
    sprintf(c, "\033[%dm%s\033[0m",color_code,text);
    printf("%s",c);}
Transaction depiler (TransactionStack *stack )
{ Noeud * temp;
Transaction trans;
if (stack->sommet == NULL) {
        color_text("La pile est vide, impossible de depiler.\n",31);
        // En cas d'erreur, retourner une transaction avec des valeurs par defaut
        Transaction emptyTrans = {0, 0.0, 0.0, 0.0, "", ""};
        return emptyTrans;
    } else {
        trans = stack->sommet->transactions;
        temp = stack->sommet;
        stack->sommet = stack->sommet->suiv;
        free(temp);
        return trans;
    }
}


void creercompte(CompteBancaire **liste) {
    bool test;
    int n;
    CompteBancaire *nouveauCompte = (CompteBancaire *)malloc(sizeof(CompteBancaire));

    if (nouveauCompte == NULL) {
        color_text("Erreur d'allocation de memoire.\n",31);
        return;
    }

    printf("Entrez votre ID: ");
    scanf("%d", &nouveauCompte->clt.clientID);
    printf("Entrez votre nom: ");
    scanf("%s", nouveauCompte->clt.nom);
    printf("Entrez votre prenom: ");
    scanf("%s", nouveauCompte->clt.prenom);
    printf("Entrez votre adresse: ");
    scanf("%s", nouveauCompte->clt.adr);
    nouveauCompte->solde = 0.0;
    nouveauCompte->suivant = NULL;

    do {
        test = false;
        n = rand() % 90000000 + 10000000;

        CompteBancaire *temp = *liste;
        while (temp != NULL) {
            if (n == temp->numcompte) {
                test = true;
                break;
            }
            temp = temp->suivant;
        }
    } while (test);

    nouveauCompte->numcompte = n;

    if (*liste == NULL) {
        *liste = nouveauCompte;
    } else {
        CompteBancaire *temp = *liste;
        while (temp->suivant != NULL) {
            temp = temp->suivant;
        }
        temp->suivant = nouveauCompte;
    }
    color_text("Compte ajoute avec succes.\n",33);
    printf("Votre numero de compte est : %d\n", n);
}
void detailscompte(CompteBancaire *liste , int numc){
    CompteBancaire *temp = liste;
    while (temp != NULL) {
        if (temp->numcompte == numc) {
            printf("Numero du compte : %d\n", temp->numcompte);
            printf("ID du titulaire : %d\n", temp->clt.clientID);
            printf("Nom du titulaire : %s\n", temp->clt.nom);
            printf("Prenom du titulaire : %s\n", temp->clt.prenom);
            printf("Adresse du titulaire : %s\n", temp->clt.adr);
            printf("Solde du compte : %.2f\n", temp->solde);
            return;
        }
        temp = temp->suivant;
    }
    printf("Le compte avec le numero %d n'existe pas.\n", numc);
}
void supprimercompte(CompteBancaire *liste , int numc){
    CompteBancaire *temp = liste;
    CompteBancaire *prec = NULL;
    while (temp != NULL && temp->numcompte!=numc) {
        prec=temp;
        temp=temp->suivant;
    }
    if(temp != NULL){
        if (prec==NULL){       //si le compte en tete
            liste=temp->suivant;
        }else{
            prec->suivant=temp->suivant;
        }
        printf("Le compte avec le numero %d a ete supprime.\n", temp->numcompte);
        free(temp);
    }else{
        printf("Le compte avec le numero %d n'existe pas.\n", numc);
    }
}
void listeclients(CompteBancaire *liste ){
    CompteBancaire *temp = liste;
    CompteBancaire *prec = NULL;
    CompteBancaire *aux=liste->suivant;
    if(liste==NULL){
        color_text("Aucun client n'est enregistre.\n",31);
    }else{
        color_text("Liste des clients :\n",33);
        while (liste != NULL) {
            while (aux != NULL){
                if (liste->clt.clientID==aux->clt.clientID){
                    while (temp != NULL && temp->numcompte!=aux->numcompte) {
                        prec=temp;
                        temp=temp->suivant;
                         }
                         if(temp != NULL){
                             if (prec==NULL){
                                 liste=temp->suivant;
                             }else{
                                 prec->suivant=temp->suivant;
                                         }
                              }}
            aux=aux->suivant;
            }
            printf("ID du client : %d, Nom et prenom du client :%s %s\n", liste->clt.clientID, liste->clt.nom,liste->clt.prenom);
            liste=liste->suivant;
    }
    }
}
void miseajour(CompteBancaire *liste, int numc){
    CompteBancaire *aux = liste;
    while(aux != NULL){
        if (aux->numcompte==numc){
            printf("Entrez votre nouveau ID : ");
            scanf("%d", &aux->clt.clientID);
            printf("Entrez votre nouveau nom : ");
            scanf("%s", aux->clt.nom);
            printf("Entrez votre nouveau prenom : ");
            scanf("%s", aux->clt.prenom);
            printf("Entrez le nouveau solde du compte : ");
            scanf("%f", &aux->solde);
            printf("Les informations du compte avec le numero %d ont ete mises a jour.\n", numc);
            return;
        }
        aux = aux->suivant;
    }
    printf("Le compte avec le numero %d n'existe pas.\n", numc);
}
void depot (CompteBancaire *liste , int numc , float montant ){
    while(liste != NULL){
        if (liste->numcompte==numc){
            liste->solde+=montant;
        }
        liste= liste->suivant;
    }}
void retrait (CompteBancaire *liste , int numc , float montant){
     while(liste != NULL){
        if (liste->numcompte==numc){
            if (liste->solde >= montant){
                liste->solde-=montant;
            }else{
                color_text("retrait inpossible\n",31);
            }

        }
        liste= liste->suivant;
    }
}
void virement(CompteBancaire *liste, int numc1 ,int numc2 , float montant){
    while(liste != NULL){
        if (liste->numcompte==numc1){
            if (liste->solde >= montant){
                liste->solde-=montant;
            }else{
                color_text("solde insufisant\n",31);
            }
        }
        if (liste->numcompte==numc2){
            liste->solde+=montant;
        }
        liste= liste->suivant;
}}
Transaction transactionbancaire (CompteBancaire *liste, int numc){
    int choix,numc2;
    Transaction trans;
    float x;
    trans.numcompte=numc;
    trans.soldeavant=liste->solde;
    time_t currentTime;
    struct tm *localTime;
    time(&currentTime);
    localTime = localtime(&currentTime);
    sprintf(trans.date, "%02d/%02d/%d", localTime->tm_mday, localTime->tm_mon + 1, localTime->tm_year + 1900);

    color_text("1.",33);printf("Retrait\n");
    color_text("2.",33);printf("Depot\n");
    color_text("3.",33);printf("Virement\n");
    color_text("4.",33);printf("Retour\n");
    printf("entrez votre choix\n");
    scanf("%d",&choix);
    switch (choix){
        case 1:
        printf("entrez le montant a retirer \n");
        scanf("%f",&x);
        retrait(liste,numc,x);
        sprintf(trans.description, "retrait");
        trans.montant=x;
        trans.soldeapres=liste->solde;
        break;
        case 2:
        printf("entrez le montant a mettre \n");
        scanf("%f",&x);
        depot(liste,numc,x);
        sprintf(trans.description, "depot");
        trans.montant=x;
        trans.soldeapres=liste->solde;
        break;
        case 3:
        printf("entrez le compte de reception \n");
        scanf("%d",&numc2);
        printf("entrez le montant a envoyer \n");
        scanf("%f",&x);
        virement(liste,numc,numc2,x);
        sprintf(trans.description, "virement vers %d", numc2);
        trans.montant=x;
        trans.soldeapres=liste->solde;
        break;
        default:
          break ;   
    }
    return trans;
}

void affichetrans(TransactionStack *stack, int numc) {
    if (stack == NULL || stack->sommet == NULL) {
        color_text("Erreur: Stack est vide.\n",31);
        return;
    }

    TransactionStack *aux = (TransactionStack *)malloc(sizeof(TransactionStack));
    aux->sommet = NULL;
    bool test=false;
    Transaction y;
    while (stack->sommet != NULL) {
        y = depiler(stack);
        if (y.numcompte == numc) {
            printf(" %s de %f le %s: solde avant: %f solde apres: %f \n",  y.description,y.montant, y.date, y.soldeavant, y.soldeapres);
            test=true;
        }
        empiler(aux, y);
    }
    if (test==false){
        printf("aucune transaction pour le compte %d",numc);}
    while (aux->sommet != NULL) { 
        y = depiler(aux);
        empiler(stack, y);
    }

    free(aux);
}
void affichetransjour(TransactionStack *stack, char jour[15]) {
    if (stack == NULL || stack->sommet == NULL) {
        color_text("Stack est vide.\n",31);
        return;
    }
    TransactionStack *aux = (TransactionStack *)malloc(sizeof(TransactionStack));
    aux->sommet = NULL;
    bool test=false;
    Transaction y;
    while (stack->sommet != NULL) {
        y = depiler(stack);
        if (strcmp(y.date, jour) == 0) {
            printf(" %s de %f du compte %d: solde avant: %f solde apres: %f \n",  y.description,y.montant, y.numcompte, y.soldeavant, y.soldeapres);
            test=true;
        }
        empiler(aux, y);
    }
    if (test==false){
        printf("aucune transaction pour le %s",jour);
    }
    while (aux->sommet != NULL) {
        y = depiler(aux);
        empiler(stack, y);
    }

    free(aux);
}


int main() {
    CompteBancaire *listeComptes = NULL;
    TransactionStack *stack = (TransactionStack *)malloc(sizeof(TransactionStack));
    stack->sommet = NULL;
    
    int choix1,choix2,choix3;
    int j,m,a;
    char jour[15];
    

    
    do {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | FOREGROUND_INTENSITY);
        printf("\nBienvenue dans E-Bank\n");
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        printf("\nVous etes\n");
        color_text("1.",36);printf("utilisateur\n");
        color_text("2.",36);printf("administrateur\n");
        color_text("3.",36);printf("Quitter\n");
        printf("Entrez votre choix : ");
        scanf("%d", &choix1);
        system("cls");
        switch (choix1) {
            case 1: {
                 do {
                     color_text("1.",36);printf("creer un nouveau compte\n");
                     color_text("2.",36);printf("Afficher les details d'un compte existant\n");
                     color_text("3.",36);printf("Mettre a jour les informations d'un compte existant\n");
                     color_text("4.",36);printf("Supprimer un compte existant\n");
                     color_text("5.",36);printf("Faire une transaction bancaire\n");
                     color_text("6.",36);printf("Afficher les transactions d'un compte existant\n");
                     color_text("7.",36);printf("Retour\n");
                     printf("Entrez votre choix : ");
                     scanf("%d", &choix2);
                     system("cls");
                     switch (choix2) {
                          case 1:
                             creercompte(&listeComptes);
                             break;
                         case 2:{
                             int numc1;
                             printf("Entrez le numero du compte : ");
                             scanf("%d", &numc1);
                             detailscompte(listeComptes, numc1);
                             break;
                             }
                         case 3:{
                             int numc2;
                             printf("Entrez le numero du compte a mettre a jour : ");
                             scanf("%d", &numc2);
                             miseajour(listeComptes, numc2);
                             break;
                         }
                         case 4:{
                             int numc3;
                             printf("Entrez le numero du compte a supprimer : ");
                             scanf("%d", &numc3);
                             supprimercompte(listeComptes, numc3);
                             break;
                             }
                         case 5:{
                             int numc4;
                             printf("Entrez le numero de compte pour effectuer une transaction : ");
                             scanf("%d", &numc4);
                             empiler(stack,transactionbancaire(listeComptes, numc4));
                             break;
                             }
                         case 6:{
                             int numc5;
                             printf("Entrez le numero de compte pour afficher les transactions : ");
                             scanf("%d", &numc5);
                             affichetrans(stack,numc5);
                             break;
                             }
                         case 7:
                             break;
                         default:
                             color_text("Choix invalide. Veuillez choisir a nouveau.\n",31);
                        }
                    } while (choix2 != 7);
                    break;
            }

            case 2:{
            do{
                 color_text("1.",36);printf("Creer un nouveau compte\n");
                 color_text("2.",36);printf("Afficher les details d'un compte existant\n");
                 color_text("3.",36);printf("Mettre a jour les informations d'un compte existant\n");
                 color_text("4.",36);printf("Supprimer un compte existant\n");
                 color_text("5.",36);printf("Faire une transaction bancaire\n");
                 color_text("6.",36);printf("Afficher les transactions d'un compte existant\n");
                 color_text("7.",36);printf("Afficher la liste des clients\n");
                 color_text("8.",36);printf("Afficher les transactions d'un jour precis\n");
                 color_text("9.",36);printf("Retour\n");
                 printf("Entrez votre choix : ");
                 scanf("%d", &choix3);
                 system("cls");
                 switch (choix3) {
                    case 1:
                             creercompte(&listeComptes);
                             break;
                    case 2: {
                             int numc6;
                             printf("Entrez le numero du compte : ");
                             scanf("%d", &numc6);
                             detailscompte(listeComptes, numc6);
                             break;
                    }
                    case 3: {
                             int numc7;
                             printf("Entrez le numero du compte a mettre a jour : ");
                             scanf("%d", &numc7);
                             miseajour(listeComptes, numc7);
                             break;
                    }
                    case 4: {
                             int numc8;
                             printf("Entrez le numero du compte a supprimer : ");
                             scanf("%d", &numc8);
                             supprimercompte(listeComptes, numc8);
                             break;
                    }
                    case 5: {
                             int numc9;
                             printf("Entrez le numero de compte pour effectuer une transaction : ");
                             scanf("%d", &numc9);
                             empiler(stack,transactionbancaire(listeComptes, numc9));
                             break;
                    }
                    case 6: {
                             int numc;
                             printf("Entrez le numero de compte pour afficher les transactions : ");
                             scanf("%d", &numc);
                             affichetrans(stack,numc);
                             break;
                    }
                    case 7:
                             listeclients(listeComptes);
                             break;
                    case 8: {
                             printf("donner le jour\n");
                             scanf("%d",&j);
                             printf("donner le mois\n");
                             scanf("%d",&m);
                             printf("donner l'annee\n");
                             scanf("%d",&a);
                             sprintf(jour, "%02d/%02d/%d",j,m,a); 
                             affichetransjour(stack,jour);
                             break;
                    }
                    case 9:
                             break;
                    default:
                             color_text("Choix invalide. Veuillez choisir a nouveau.\n",31);
                 }      
                 }while (choix3 != 9);
                 break;
            }

            case 3:
                color_text("Merci d'avoir utilise E-Bank. Au revoir !\n",32);
                break;
            default:
                color_text("Choix invalide. Veuillez choisir a nouveau.\n",31);
        }
    }while (choix1 != 3);
    CompteBancaire *temp;
    while (listeComptes != NULL) {
        temp = listeComptes;
        listeComptes = listeComptes->suivant;
        free(temp);
    }
    free(stack->sommet);
    free(stack);
    return 0;
}  